/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Deck.cpp
 * Author: john
 * 
 * Created on November 6, 2017, 7:44 AM
 */

#include "Deck.h"

Deck::Deck(int c) {
    
    srand (time(NULL));
    for(int i = 0; i<NUM_CARDS; i++){
        cards.push_back(new Card(i%13, i)); 
        
    }
    shuffle();
    
}

vector<Card*> Deck::getCards(){
    
    return cards;
    
}
Deck::Deck(const Deck& orig) {
}

Deck::~Deck() {
}

void Deck::shuffle(){
    
    for(int i = 0; i<NUM_CARDS; i++){
        int r1 = rand()%NUM_CARDS;
        int r2 = rand()%NUM_CARDS;
        Card* temp1 = cards[r1];
        Card* temp2 = cards[r2];
        cards[r1] = temp2;
        cards[r2] = temp1;
    }
    
    
}


Card Deck::play(){
    
    Card c = *cards.back();
    cards.pop_back();
    return c;
    
}




void Deck::debug(){
    printf("\n");
    for(int i = 0; i<NUM_CARDS; i++){
        cards[i]->debug();
    }
}
