/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.cpp
 * Author: john
 * 
 * Created on November 6, 2017, 7:44 AM
 */

#include "Player.h"

Player::Player(vector<Card*> c) {
    
    
    
    for(int i = 0; i< c.size(); i++){
        
        cards.push_back(c[i]);
        
    }
    
}

Player::Player(const Player& orig) {
}

Player::~Player() {

}



void Player::debug(){
    for(int i = 0; i< cards.size(); i++){
        cards[i]->debug();
    }
}