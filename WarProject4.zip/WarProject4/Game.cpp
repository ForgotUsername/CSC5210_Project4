/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.cpp
 * Author: john
 * 
 * Created on November 6, 2017, 8:46 AM
 */

#include "Game.h"

Game::Game() {
    deck = new Deck(52);
    //deck->shuffle();
    vector<Card*> p1;
    vector<Card*> p2;
    for(int i = 0; i<26; i++){
        p1.push_back(deck->getCards()[i]);
    }
    for(int i = 26; i<52; i++){
        p2.push_back(deck->getCards()[i]);
    }
    playerOne = new Player(p1);
    playerTwo = new Player(p2);
    printf("Player1:\n");
    playerOne->debug();
    printf("\nPlayer2:\n");
    playerTwo->debug();
    while(1);
}

Game::Game(const Game& orig) {
}

Game::~Game() {

}


