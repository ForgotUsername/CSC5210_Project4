/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Card.h
 * Author: john
 *
 * Created on November 6, 2017, 7:44 AM
 */

#ifndef CARD_H
#define CARD_H

#include <stdio.h>
#include <iostream>
#include <sstream>

using namespace std;

class Card {
public:
    Card(int value, int suite);
    
    void debug();
    virtual ~Card();
private:
    int value;
    char suite;
    string pngFile = "";
};

#endif /* CARD_H */

